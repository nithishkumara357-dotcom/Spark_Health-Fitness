import { useEffect, useMemo, useState } from 'react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';
const fallbackCreators = [
  { id: 'c1', name: 'Ananya Sharma', category: 'Career Coach', emoji: '👩‍💻', bio: 'Career guidance, interview practice and job-search strategies.', monthlyPrice: 199, callPrice: 299, verified: true },
  { id: 'c2', name: 'Arjun Kumar', category: 'Tech Mentor', emoji: '👨‍💻', bio: 'Learn coding, build portfolio projects and prepare for IT interviews.', monthlyPrice: 149, callPrice: 249, verified: true },
  { id: 'c3', name: 'Priya Raj', category: 'Language Tutor', emoji: '👩‍🏫', bio: 'Practice spoken English and build communication confidence.', monthlyPrice: 179, callPrice: 199, verified: false },
  { id: 'c4', name: 'Karthik Raman', category: 'Data Analyst', emoji: '📊', bio: 'Excel, SQL and Power BI guidance for beginner analysts.', monthlyPrice: 229, callPrice: 349, verified: true },
  { id: 'c5', name: 'Meera Iyer', category: 'Design Mentor', emoji: '🎨', bio: 'Get feedback on UI design, portfolios and creative projects.', monthlyPrice: 189, callPrice: 279, verified: false },
  { id: 'c6', name: 'Vikram Das', category: 'Fitness Coach', emoji: '🏃', bio: 'General fitness accountability and habit-building sessions.', monthlyPrice: 249, callPrice: 399, verified: true },
];
const categories = ['All', ...new Set(fallbackCreators.map((c) => c.category))];

export default function App() {
  const [creators, setCreators] = useState(fallbackCreators);
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState('');
  const [modal, setModal] = useState(null);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [requestName, setRequestName] = useState('');
  const [requestEmail, setRequestEmail] = useState('');
  const [health, setHealth] = useState('Checking API…');

  useEffect(() => {
    fetch(`${API}/health`).then((r) => r.json()).then(() => setHealth('Demo API connected')).catch(() => setHealth('Local demo mode'));
    fetch(`${API}/creators`).then((r) => { if (!r.ok) throw new Error('API unavailable'); return r.json(); })
      .then((data) => { if (Array.isArray(data) && data.length) setCreators(data); }).catch(() => {});
  }, []);

  const visibleCreators = useMemo(() => creators.filter((c) => {
    const matchesCategory = category === 'All' || c.category === category;
    const q = search.trim().toLowerCase();
    const matchesSearch = !q || `${c.name} ${c.category} ${c.bio}`.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  }), [creators, category, search]);

  async function subscribe(creator) {
    setNotice(`Demo only: selected ₹${creator.monthlyPrice}/month membership for ${creator.name}. No payment was taken.`);
    setModal({ type: 'subscription', creator });
  }

  function openBooking(creator) {
    setBookingDate(''); setBookingTime(''); setRequestName(''); setRequestEmail('');
    setModal({ type: 'booking', creator });
  }

  async function submitBooking(event) {
    event.preventDefault();
    if (!modal?.creator || !bookingDate || !bookingTime || !requestName.trim() || !requestEmail.trim()) return;
    const payload = { creatorId: modal.creator.id, creatorName: modal.creator.name, customerName: requestName.trim(), customerEmail: requestEmail.trim(), date: bookingDate, time: bookingTime, price: modal.creator.callPrice };
    try {
      const response = await fetch(`${API}/bookings`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not create booking');
      setNotice(`Booking request created (${result.booking.id}). This is a demo request; it is not paid or a confirmed call.`);
    } catch (error) {
      setNotice(`Demo booking request for ${modal.creator.name} on ${bookingDate} at ${bookingTime}. Backend unavailable; no payment or call was made.`);
    }
    setModal(null);
  }

  return <div className="app-shell">
    <header className="navbar">
      <a className="brand" href="#home"><span className="brand-mark">C</span> CreatorConnect</a>
      <nav><a href="#creators">Explore</a><a href="#how">How it works</a></nav>
      <a className="nav-cta" href="#creators">Find a creator <span>↗</span></a>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot" /> CREATOR MEMBERSHIPS & 1:1 SESSIONS</div>
          <h1>Your next big step starts with a <span>conversation.</span></h1>
          <p>Learn from people who have been there. Join creator communities or request a one-to-one session when it works for both of you.</p>
          <div className="hero-actions"><a className="button primary" href="#creators">Explore creators <span>→</span></a><a className="text-link" href="#how">How it works <span>↓</span></a></div>
          <div className="trust-row"><div className="avatar-stack"><span>👩🏻</span><span>👨🏽</span><span>👩🏽</span></div><div><strong>Learn at your pace</strong><small>Transparent pricing · Consent-first calls</small></div></div>
        </div>
        <div className="hero-art" aria-label="Illustration of people connecting online">
          <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
          <div className="art-card card-back"><span className="mini-icon">✦</span><div className="skeleton-line long"/><div className="skeleton-line"/><div className="mini-pill">Creator community</div></div>
          <div className="art-person person-one"><span>👩🏽‍💻</span><div className="person-label"><strong>Ananya S.</strong><small>Career Coach</small></div></div>
          <div className="art-person person-two"><span>👨🏻‍💻</span><div className="person-label"><strong>Arjun K.</strong><small>Tech Mentor</small></div></div>
          <div className="floating-note"><span className="note-icon">✓</span><div><strong>Made for mutual choice</strong><small>Accept before a call connects</small></div></div>
          <div className="sparkle sparkle-a">✦</div><div className="sparkle sparkle-b">✧</div>
        </div>
      </section>

      <section className="stats-strip"><div><strong>Memberships</strong><span>Monthly creator support</span></div><i/><div><strong>1:1 sessions</strong><span>Book at a chosen time</span></div><i/><div><strong>Clear pricing</strong><span>No surprise charges</span></div></section>

      <section className="creator-section" id="creators">
        <div className="section-top"><div><div className="eyebrow">FIND YOUR PEOPLE</div><h2>Meet your next mentor</h2><p>Explore sample profiles and choose the kind of guidance you need.</p></div><div className="api-status"><span className="status-dot"/>{health}</div></div>
        <div className="search-row"><label className="search-box"><span>⌕</span><input aria-label="Search creators" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search creators, skills or topics" /></label><span className="result-count">{visibleCreators.length} profiles</span></div>
        <div className="filters">{categories.map((item) => <button key={item} className={`filter ${category === item ? 'active' : ''}`} onClick={() => setCategory(item)}>{item}</button>)}</div>
        <div className="creator-grid">{visibleCreators.map((creator, index) => <article className="creator-card" key={creator.id}>
          <div className={`creator-cover cover-${index % 6}`}><span className="creator-emoji">{creator.emoji}</span><span className="cover-symbol">✦</span></div>
          <div className="creator-body"><div className="creator-meta"><span className="category-tag">{creator.category}</span>{creator.verified && <span className="verified">✓ Verified demo</span>}</div><h3>{creator.name}</h3><p className="bio">{creator.bio}</p>
            <div className="price-box"><div><small>Membership</small><strong>₹{creator.monthlyPrice}<span>/mo</span></strong></div><div className="price-divider"/><div><small>1:1 session</small><strong>₹{creator.callPrice}<span>/session</span></strong></div></div>
            <button className="button primary full" onClick={() => subscribe(creator)}>View membership <span>→</span></button><button className="button secondary full" onClick={() => openBooking(creator)}>Request a session</button>
          </div></article>)}</div>
        {visibleCreators.length === 0 && <div className="empty-state"><span>⌕</span><h3>No creators found</h3><p>Try another search term or category.</p></div>}
        {notice && <div className="notice" role="status"><span className="notice-icon">i</span><p>{notice}</p><button aria-label="Dismiss notice" onClick={() => setNotice('')}>×</button></div>}
      </section>

      <section className="how-section" id="how"><div className="eyebrow">SIMPLE BY DESIGN</div><h2>A better way to learn together</h2><div className="how-grid"><div className="how-card"><span className="step-num">01</span><div className="how-icon">⌕</div><h3>Find your creator</h3><p>Browse profiles, topics and transparent prices before choosing.</p></div><div className="how-card"><span className="step-num">02</span><div className="how-icon">♡</div><h3>Join or request</h3><p>Choose a membership or request a session at a suitable time.</p></div><div className="how-card"><span className="step-num">03</span><div className="how-icon">↗</div><h3>Connect by consent</h3><p>A real call should only happen after both sides agree and the booking is confirmed.</p></div></div></section>
      <section className="creator-cta"><div><div className="eyebrow light">FOR CREATORS</div><h2>Turn what you know into something valuable.</h2><p>Build a community around your skills. Creator onboarding is a planned next feature.</p></div><button className="button white" onClick={() => setNotice('Creator registration is not enabled in this starter version. It will be added in the next milestone.')}>Become a creator <span>→</span></button></section>
    </main>

    <footer><a className="brand" href="#home"><span className="brand-mark">C</span> CreatorConnect</a><p>Learn from people. Build something meaningful.</p><div className="footer-bottom"><span>© 2026 CreatorConnect starter project</span><span>Demo mode · No real payments or calls</span></div></footer>

    {modal && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) setModal(null); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="modal-close" onClick={() => setModal(null)} aria-label="Close">×</button>
      {modal.type === 'subscription' ? <><div className="modal-icon">✦</div><div className="eyebrow">MEMBERSHIP PREVIEW</div><h2 id="modal-title">Support {modal.creator.name}</h2><p className="modal-copy">Explore a sample membership plan. Checkout is not connected yet, so you will not be charged.</p><div className="membership-summary"><span>Monthly membership</span><strong>₹{modal.creator.monthlyPrice}<small> / month</small></strong><ul><li>Access to creator updates (planned)</li><li>Member-only content (planned)</li><li>Cancel according to the published terms</li></ul></div><button className="button primary full" onClick={() => { setNotice(`Membership preview for ${modal.creator.name}: ₹${modal.creator.monthlyPrice}/month. Demo only — no charge made.`); setModal(null); }}>Continue in demo mode</button></> : <><div className="modal-icon">◷</div><div className="eyebrow">SESSION REQUEST</div><h2 id="modal-title">Request time with {modal.creator.name}</h2><p className="modal-copy">Choose a time and submit a request. This does not confirm a booking or start a call.</p><form className="booking-form" onSubmit={submitBooking}><label>Your name<input required value={requestName} onChange={(e) => setRequestName(e.target.value)} placeholder="Full name" /></label><label>Email address<input required type="email" value={requestEmail} onChange={(e) => setRequestEmail(e.target.value)} placeholder="you@example.com" /></label><div className="form-two"><label>Preferred date<input required type="date" min={new Date().toISOString().slice(0, 10)} value={bookingDate} onChange={(e) => setBookingDate(e.target.value)} /></label><label>Preferred time<select required value={bookingTime} onChange={(e) => setBookingTime(e.target.value)}><option value="">Choose time</option><option>10:00</option><option>12:00</option><option>15:00</option><option>17:00</option><option>19:00</option></select></label></div><div className="booking-total"><span>Session price</span><strong>₹{modal.creator.callPrice}</strong></div><button className="button primary full" type="submit">Submit demo request <span>→</span></button><small className="privacy-note">Use test details only. Do not enter payment information.</small></form></>}
    </section></div>}
  </div>;
}
