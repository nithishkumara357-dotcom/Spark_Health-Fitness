# CreatorConnect

A beginner-friendly starter for a creator membership and consent-based paid-session platform. It includes a responsive React website and a small Express API for sample creator profiles and demo booking requests.

## What works now

- Responsive creator discovery homepage
- Search and category filters
- Sample membership pricing and demo membership modal
- Session request form with basic server-side validation
- Express API endpoints: `GET /api/health`, `GET /api/creators`, `POST /api/bookings`
- Demo bookings are held in server memory and reset when the API restarts

## What is NOT implemented

This is not production-ready and does **not** include real user accounts, permanent database storage, real subscriptions, real payments, creator payouts, real video/audio calls, moderation tooling, or an admin panel. No money is collected. Do not advertise it as a live paid service yet.

## Requirements

- Node.js 20+ recommended
- npm
- VS Code (optional)

## Run locally on Windows

Open the project folder in VS Code, then open Terminal in the project root:

```bash
npm run install:all
npm run dev
```

Open `http://localhost:5173`. The API runs at `http://localhost:4000`.

If your terminal says PowerShell execution policy errors, use the VS Code Command Prompt terminal or run the commands from Windows Command Prompt.

## Run each service separately

Terminal 1:

```bash
npm --prefix server install
npm --prefix server run dev
```

Terminal 2:

```bash
npm --prefix client install
npm --prefix client run dev
```

## GitHub upload

1. Create a new empty repository on GitHub, for example `creatorconnect`.
2. Extract this project ZIP.
3. Open the extracted `creatorconnect` folder in VS Code.
4. Do not commit `.env` files or private credentials. The `.gitignore` excludes common environment files.
5. In a terminal run:

```bash
git init
git add .
git commit -m "Initial CreatorConnect starter"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/creatorconnect.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not paste a GitHub password or token into source code.

## Production milestones

1. Add Firebase Authentication and protected creator/customer profiles.
2. Use Firestore or another persistent database, security rules and server-side authorization.
3. Add creator availability, mutual acceptance, cancellations, refunds, report/block, age gating, privacy policy and terms.
4. Integrate a supported payment provider only after account and business-model approval. Create orders on the server, verify payment signatures and verify payment status before granting access. Keep secret keys on the server only.
5. Design a compliant marketplace payout process and verify KYC, settlement, tax, refund and provider requirements.
6. Integrate a video SDK and generate short-lived access tokens on the server. Never place provider secrets in frontend code.
7. Add tests, rate limiting, logging, abuse prevention, data retention rules and privacy/security review before launch.
8. Package the web app for Android with Capacitor after testing the web experience. Review Google Play's current payment and user-generated-content policies before publishing.

## Environment configuration

The API has defaults for local development. To customize it, copy `server/.env.example` to `server/.env` and adjust values. Never commit secrets.

## License

Choose and add a license before accepting outside contributions or distributing this project.
