import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { randomUUID } from 'node:crypto';

const app = express();
const port = Number(process.env.PORT || 4000);
const allowedOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
app.use(helmet());
app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: '20kb' }));

const creators = [
  { id: 'c1', name: 'Ananya Sharma', category: 'Career Coach', emoji: '👩‍💻', bio: 'Career guidance, interview practice and job-search strategies.', monthlyPrice: 199, callPrice: 299, verified: true },
  { id: 'c2', name: 'Arjun Kumar', category: 'Tech Mentor', emoji: '👨‍💻', bio: 'Learn coding, build portfolio projects and prepare for IT interviews.', monthlyPrice: 149, callPrice: 249, verified: true },
  { id: 'c3', name: 'Priya Raj', category: 'Language Tutor', emoji: '👩‍🏫', bio: 'Practice spoken English and build communication confidence.', monthlyPrice: 179, callPrice: 199, verified: false },
  { id: 'c4', name: 'Karthik Raman', category: 'Data Analyst', emoji: '📊', bio: 'Excel, SQL and Power BI guidance for beginner analysts.', monthlyPrice: 229, callPrice: 349, verified: true },
  { id: 'c5', name: 'Meera Iyer', category: 'Design Mentor', emoji: '🎨', bio: 'Get feedback on UI design, portfolios and creative projects.', monthlyPrice: 189, callPrice: 279, verified: false },
  { id: 'c6', name: 'Vikram Das', category: 'Fitness Coach', emoji: '🏃', bio: 'General fitness accountability and habit-building sessions.', monthlyPrice: 249, callPrice: 399, verified: true },
];
// Demo-only in-memory storage. Data resets whenever this server restarts.
const bookings = [];

app.get('/api/health', (_req, res) => res.json({ ok: true, mode: 'demo', message: 'CreatorConnect demo API is running' }));
app.get('/api/creators', (_req, res) => res.json(creators));
app.get('/api/bookings', (_req, res) => {
  // Demo endpoint only. Do not expose booking data publicly in a production app.
  res.json(bookings.map(({ customerEmail, ...safeBooking }) => safeBooking));
});
app.post('/api/bookings', (req, res) => {
  const { creatorId, customerName, customerEmail, date, time } = req.body || {};
  const creator = creators.find((item) => item.id === creatorId);
  if (!creator) return res.status(400).json({ error: 'Please choose a valid creator.' });
  if (typeof customerName !== 'string' || customerName.trim().length < 2 || customerName.length > 100) return res.status(400).json({ error: 'Enter a valid name.' });
  if (typeof customerEmail !== 'string' || customerEmail.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(`${date}T00:00:00Z`))) return res.status(400).json({ error: 'Choose a valid date.' });
  if (Date.parse(`${date}T00:00:00Z`) < Date.parse(`${new Date().toISOString().slice(0, 10)}T00:00:00Z`)) return res.status(400).json({ error: 'Choose today or a future date.' });
  if (typeof time !== 'string' || !['10:00', '12:00', '15:00', '17:00', '19:00'].includes(time)) return res.status(400).json({ error: 'Choose an available demo time.' });
  const booking = {
    id: `demo_${randomUUID().slice(0, 8)}`,
    creatorId: creator.id,
    creatorName: creator.name,
    customerName: customerName.trim(),
    customerEmail: customerEmail.trim().toLowerCase(),
    date,
    time,
    price: creator.callPrice,
    status: 'REQUESTED_DEMO_ONLY',
    paid: false,
    createdAt: new Date().toISOString(),
  };
  bookings.push(booking);
  res.status(201).json({ booking: { ...booking, customerEmail: undefined }, message: 'Demo request created. No payment was taken and no call is confirmed.' });
});
app.use((_req, res) => res.status(404).json({ error: 'Route not found' }));
app.use((err, _req, res, _next) => {
  console.error('API error:', err.message);
  res.status(500).json({ error: 'Unexpected server error.' });
});
app.listen(port, () => console.log(`CreatorConnect demo API listening on http://localhost:${port}`));
