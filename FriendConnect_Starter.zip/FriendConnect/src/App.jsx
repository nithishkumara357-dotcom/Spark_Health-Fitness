import { useEffect, useMemo, useState } from "react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, updateProfile
} from "firebase/auth";
import {
  addDoc, collection, doc, onSnapshot, orderBy, query, serverTimestamp,
  setDoc, where
} from "firebase/firestore";
import { auth, db, firebaseConfigured } from "./firebase";
import { Heart, MessageCircle, UserRound, ShieldCheck, LogOut, Send, CreditCard, Users, Sparkles } from "lucide-react";

const plans = [
  { id: "weekly", name: "Weekly", price: "₹—", note: "7 days" },
  { id: "monthly", name: "Monthly", price: "₹—", note: "30 days" },
  { id: "yearly", name: "Yearly", price: "₹—", note: "365 days" },
];

function AuthScreen() {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      if (!firebaseConfigured) throw new Error("Firebase setup pending. Follow README.md first.");
      if (mode === "signup") {
        const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(credential.user, { displayName: name.trim() || "Friend" });
        await setDoc(doc(db, "users", credential.user.uid), {
          displayName: name.trim() || "Friend", email: email.trim(),
          bio: "", interests: [], photoURL: "", createdAt: serverTimestamp(),
          // Role is deliberately NOT set here. Admin role must be provisioned securely.
        });
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (err) { setError(err.message || "Something went wrong."); }
    finally { setBusy(false); }
  }

  return <main className="auth-wrap">
    <section className="auth-card">
      <div className="brand-mark"><Heart fill="currentColor" size={25}/></div>
      <p className="eyebrow">YOUR PEOPLE, YOUR COMMUNITY</p>
      <h1>FriendConnect</h1>
      <p className="muted">Make meaningful connections, one conversation at a time.</p>
      {!firebaseConfigured && <div className="notice">Firebase setup pending. You can view the UI, but authentication needs the setup steps in README.md.</div>}
      <form onSubmit={submit} className="stack">
        {mode === "signup" && <label>Your name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Display name" maxLength={60} required /></label>}
        <label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required /></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" minLength={6} required /></label>
        {error && <p className="error">{error}</p>}
        <button className="primary" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Log in" : "Create account"}</button>
      </form>
      <p className="switch-auth">{mode === "login" ? "New to FriendConnect?" : "Already have an account?"}{" "}
        <button className="text-button" onClick={()=>{setMode(mode==="login"?"signup":"login");setError("");}}>{mode==="login"?"Sign up":"Log in"}</button>
      </p>
    </section>
  </main>;
}

function AppShell({ user }) {
  const [tab, setTab] = useState("home");
  const [profile, setProfile] = useState({ displayName: user.displayName || "", bio: "", interests: "", photoURL: "" });
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState("");
  const [plansList, setPlansList] = useState(plans);
  const [qrUrl, setQrUrl] = useState("");
  const [paymentRef, setPaymentRef] = useState("");
  const [paymentPlan, setPaymentPlan] = useState("monthly");
  const [paymentStatus, setPaymentStatus] = useState("");
  const [notice, setNotice] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (!db || !user) return;
    const stopUsers = onSnapshot(collection(db, "users"), snap => {
      setUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(u => u.id !== user.uid));
    }, err => setNotice("Could not load profiles: " + err.message));
    const stopMe = onSnapshot(doc(db, "users", user.uid), snap => {
      if (snap.exists()) {
        const d = snap.data();
        setProfile({ displayName: d.displayName || user.displayName || "", bio: d.bio || "", interests: (d.interests || []).join(", "), photoURL: d.photoURL || "" });
      }
    });
    // Secure admin status should be supplied by a trusted custom claim/server.
    // This starter intentionally does not grant admin access from a client-editable field.
    user.getIdTokenResult(true).then(token => setIsAdmin(token.claims.admin === true)).catch(()=>setIsAdmin(false));
    return () => { stopUsers(); stopMe(); };
  }, [user]);

  useEffect(() => {
    if (!db || !selected || !user) { setMessages([]); return; }
    // For production, create a conversation document and use a trusted membership check.
    // This starter stores messages in a simple collection; rules must restrict participants.
    const stop = onSnapshot(query(collection(db, "messages"), where("participants", "array-contains", user.uid)), snap => {
      const all = snap.docs.map(d => ({ id:d.id, ...d.data() }));
      setMessages(all.filter(m => m.participants?.includes(selected.id)).sort((a,b)=>(a.createdAt?.seconds||0)-(b.createdAt?.seconds||0)));
    }, err => setNotice("Chat loading failed. Check Firestore rules: " + err.message));
    return () => stop();
  }, [selected, user]);

  async function saveProfile(e) {
    e.preventDefault();
    try {
      await setDoc(doc(db, "users", user.uid), {
        displayName: profile.displayName.trim() || "Friend",
        bio: profile.bio.slice(0, 240),
        interests: profile.interests.split(",").map(x=>x.trim()).filter(Boolean).slice(0, 20),
        photoURL: profile.photoURL.trim().slice(0, 500),
      }, { merge: true });
      setNotice("Profile saved.");
    } catch (e) { setNotice("Profile save failed: " + e.message); }
  }

  async function sendMessage(e) {
    e.preventDefault();
    if (!draft.trim() || !selected) return;
    try {
      await addDoc(collection(db, "messages"), {
        text: draft.trim().slice(0, 2000),
        senderId: user.uid,
        participants: [user.uid, selected.id].sort(),
        createdAt: serverTimestamp()
      });
      setDraft("");
    } catch (e) { setNotice("Message not sent: " + e.message); }
  }

  async function submitPayment(e) {
    e.preventDefault();
    if (!paymentRef.trim()) { setPaymentStatus("Enter the UPI/bank transaction reference."); return; }
    try {
      await addDoc(collection(db, "paymentRequests"), {
        userId: user.uid, planId: paymentPlan, transactionReference: paymentRef.trim().slice(0, 120),
        status: "pending", createdAt: serverTimestamp()
      });
      setPaymentRef("");
      setPaymentStatus("Request submitted. Subscription stays pending until an authorized admin verifies the transaction.");
    } catch (e) { setPaymentStatus("Could not submit: " + e.message); }
  }

  async function updateQr(e) {
    e.preventDefault();
    if (!isAdmin) return;
    try {
      await setDoc(doc(db, "settings", "payments"), { qrImageUrl: qrUrl.trim(), updatedAt: serverTimestamp() }, { merge: true });
      setNotice("QR setting saved. Ensure the URL points to an image you control.");
    } catch(e) { setNotice("QR update failed: " + e.message); }
  }

  const visibleMessages = useMemo(()=>messages, [messages]);

  return <div className="app">
    <header className="topbar">
      <div className="brand"><span className="brand-mark small"><Heart fill="currentColor" size={18}/></span><strong>FriendConnect</strong></div>
      <button className="icon-button" title="Log out" onClick={()=>signOut(auth)}><LogOut size={18}/></button>
    </header>
    <div className="layout">
      <aside className="sidebar">
        <p className="eyebrow">MENU</p>
        {[["home","Home",Sparkles],["people","Discover",Users],["chat","Messages",MessageCircle],["profile","My profile",UserRound],["plans","Subscriptions",CreditCard],...(isAdmin?[["admin","Admin panel",ShieldCheck]]:[])].map(([id,label,Icon])=>
          <button key={id} className={`nav-item ${tab===id?"active":""}`} onClick={()=>setTab(id)}><Icon size={18}/>{label}</button>)}
        <div className="sidebar-foot">Signed in as<br/><b>{user.email}</b></div>
      </aside>
      <main className="content">
        {notice && <div className="notice dismiss" onClick={()=>setNotice("")}>{notice} <span>×</span></div>}
        {tab==="home" && <section className="hero">
          <span className="pill"><Sparkles size={14}/> A kinder corner of the internet</span>
          <h1>Good connections<br/><span>start here.</span></h1>
          <p>Meet people with shared interests, discover profiles, and start a conversation.</p>
          <button className="primary compact" onClick={()=>setTab("people")}>Discover friends</button>
          <div className="feature-grid"><div className="feature"><Users/><b>Discover people</b><span>Explore community profiles.</span></div><div className="feature"><MessageCircle/><b>Real conversations</b><span>Chat with other members.</span></div><div className="feature"><ShieldCheck/><b>Safety first</b><span>Protect your personal details.</span></div></div>
        </section>}
        {tab==="people" && <section><div className="section-head"><div><p className="eyebrow">COMMUNITY</p><h2>Discover friends</h2></div><span className="pill">{users.length} profiles</span></div>
          <div className="people-grid">{users.map(p=><article className="person-card" key={p.id}><div className="avatar">{(p.displayName||"F").slice(0,1).toUpperCase()}</div><h3>{p.displayName||"Friend"}</h3><p>{p.bio||"Ready to meet new people."}</p><div className="tags">{(p.interests||[]).slice(0,3).map(x=><span key={x}>{x}</span>)}</div><button className="secondary full" onClick={()=>{setSelected(p);setTab("chat");}}> <MessageCircle size={16}/> Message</button></article>)}
          {!users.length && <div className="empty">No other profiles yet. Create another test account to try discovery.</div>}</div>
        </section>}
        {tab==="chat" && <section><div className="section-head"><div><p className="eyebrow">SAY HELLO</p><h2>Messages</h2></div></div><div className="chat-layout"><div className="chat-people">{users.map(p=><button key={p.id} className={`chat-person ${selected?.id===p.id?"selected":""}`} onClick={()=>setSelected(p)}><div className="avatar tiny">{(p.displayName||"F").slice(0,1).toUpperCase()}</div><span>{p.displayName||"Friend"}</span></button>)}</div><div className="chat-window">{selected ? <><div className="chat-heading"><div className="avatar tiny">{(selected.displayName||"F").slice(0,1).toUpperCase()}</div><b>{selected.displayName||"Friend"}</b></div><div className="chat-messages">{visibleMessages.map(m=><div key={m.id} className={`bubble ${m.senderId===user.uid?"mine":""}`}>{m.text}</div>)}</div><form className="send-row" onSubmit={sendMessage}><input value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Write a kind message…" maxLength={2000}/><button className="primary send-button" aria-label="Send message"><Send size={17}/></button></form></> : <div className="empty">Choose a profile to start chatting.</div>}</div></div></section>}
        {tab==="profile" && <section className="form-section"><p className="eyebrow">YOUR SPACE</p><h2>My profile</h2><form className="stack profile-form" onSubmit={saveProfile}><label>Display name<input value={profile.displayName} onChange={e=>setProfile({...profile,displayName:e.target.value})} maxLength={60}/></label><label>Short bio<textarea value={profile.bio} onChange={e=>setProfile({...profile,bio:e.target.value})} maxLength={240} rows={4} placeholder="A little about you…"/></label><label>Interests <span className="muted">(comma separated)</span><input value={profile.interests} onChange={e=>setProfile({...profile,interests:e.target.value})} placeholder="music, coding, travel"/></label><label>Profile photo URL <span className="muted">(optional)</span><input value={profile.photoURL} onChange={e=>setProfile({...profile,photoURL:e.target.value})} placeholder="https://…"/></label><button className="primary">Save profile</button></form></section>}
        {tab==="plans" && <section><p className="eyebrow">MEMBERSHIP</p><h2>Choose your plan</h2><p className="muted">Prices are placeholders until configured. Payment is manual and requires admin verification.</p><div className="plans-grid">{plansList.map(p=><article className="plan-card" key={p.id}><div className="plan-icon"><CreditCard/></div><h3>{p.name}</h3><div className="price">{p.price}</div><p>{p.note} access</p><button className={`secondary full ${paymentPlan===p.id?"chosen":""}`} onClick={()=>{setPaymentPlan(p.id);setPaymentStatus("");}}>Select plan</button></article>)}</div><form className="stack payment-form" onSubmit={submitPayment}><h3>Submit payment reference</h3><label>Selected plan<select value={paymentPlan} onChange={e=>setPaymentPlan(e.target.value)}>{plansList.map(p=><option value={p.id} key={p.id}>{p.name}</option>)}</select></label>{qrUrl && <img className="qr-image" src={qrUrl} alt="Admin payment QR code"/>}<label>UPI / bank transaction reference<input value={paymentRef} onChange={e=>setPaymentRef(e.target.value)} placeholder="Enter transaction reference" maxLength={120}/></label><button className="primary">Submit for review</button>{paymentStatus && <p className="notice">{paymentStatus}</p>}</form></section>}
        {tab==="admin" && <section><p className="eyebrow">RESTRICTED AREA</p><h2>Admin panel</h2>{!isAdmin ? <div className="notice">Admin claim not detected. Admin privileges must be assigned securely by a trusted backend. Do not make yourself admin by changing browser code or a profile field.</div> : <><p>Admin controls are available. Complete server-side review/approval functions before accepting real payments.</p><form className="stack profile-form" onSubmit={updateQr}><label>Payment QR image URL<input value={qrUrl} onChange={e=>setQrUrl(e.target.value)} placeholder="https://your-hosted-qr-image.png"/></label><button className="primary">Save payment QR</button></form><div className="notice">Payment request approval and price management need a trusted backend function and audit logging before production.</div></>}</section>}
        <footer>FriendConnect · Be kind. Stay safe. <span>Never share your UPI PIN or password.</span></footer>
      </main>
    </div>
    <nav className="mobile-nav">{[["home","Home",Sparkles],["people","Discover",Users],["chat","Chat",MessageCircle],["profile","Profile",UserRound],["plans","Plans",CreditCard],...(isAdmin?[["admin","Admin",ShieldCheck]]:[])].map(([id,label,Icon])=><button key={id} className={tab===id?"active":""} onClick={()=>setTab(id)}><Icon size={18}/><span>{label}</span></button>)}</nav>
  </div>;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!auth) { setLoading(false); return; }
    return onAuthStateChanged(auth, current => { setUser(current); setLoading(false); });
  }, []);
  if (loading) return <div className="loading">Loading FriendConnect…</div>;
  if (!firebaseConfigured) return <AuthScreen />;
  return user ? <AppShell user={user}/> : <AuthScreen />;
}