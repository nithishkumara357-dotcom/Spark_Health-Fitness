# FriendConnect starter

A mobile-first React + Vite + Firebase starter for FriendConnect. Built to be edited from an Android phone using GitHub Codespaces or another browser-based development environment.

## Included

- Email/password signup and login
- Profile editing and profile discovery
- Basic one-to-one message UI and Firestore writes
- Weekly, monthly and yearly plan selection (prices are placeholders)
- Manual payment-reference submission
- Admin UI gated by a Firebase custom claim (`admin: true`)
- Starter Firestore rules

## Important limitations

This is a starter, not a production-ready paid social network. Do not accept real payments until you implement and test trusted server-side payment review, subscription expiry/renewal, audit logging, moderation, blocking/reporting, privacy controls, abuse protection, and appropriate legal/privacy notices. The UI currently expects the admin payment QR URL to be configured; it does not yet fetch/display settings automatically or implement admin review actions. A payment screenshot or user-submitted reference is not proof of payment. Verify the transaction in your bank/UPI app.

Never ask users for UPI PIN, bank password, OTP, or card PIN. Never put Firebase service-account credentials in frontend code.

## 1. Create Firebase project

1. Open https://console.firebase.google.com/ in Chrome.
2. Create a project called FriendConnect.
3. In Project settings, add a Web app.
4. Copy the Firebase web configuration values.
5. Authentication -> Sign-in method -> enable Email/Password.
6. Firestore Database -> Create database. Start in production mode.
7. In Firestore Rules, paste `firestore.rules` and publish.
8. Add the Firebase web configuration values to a `.env` file based on `.env.example`. Do not commit `.env` to a public repository.

Firebase web API config is not a server secret, but database rules are essential. Never expose service account/private keys.

## 2. Run in Codespaces (Android)

1. Upload/extract this project into a GitHub repository.
2. Open the repo in GitHub Codespaces.
3. In the terminal run `npm install`.
4. Create `.env` in the project root and fill the Firebase values.
5. Run `npm run dev -- --host 0.0.0.0`.
6. Open the forwarded port 5173 in the browser.

If `.env` is added after Vite starts, stop the server with Ctrl+C and start it again.

## 3. Configure admin safely

The admin screen only appears when the signed-in Firebase ID token has the trusted custom claim `admin: true`. Do not set an admin field from the user profile or browser. Set custom claims only from a trusted server environment using Firebase Admin SDK, after verifying the intended account. Never paste service-account keys into this frontend or a public chat. After granting the claim, sign out and sign in again.

## 4. Test

- Create two test accounts using separate email addresses.
- Check profile updates and profile discovery.
- Send a message between test accounts.
- Try reading another user's private payment request; it should be denied.
- Submit a dummy payment reference and confirm it stays pending.
- Test admin access only after setting the custom claim securely.
- Test mobile layout at 320px, 375px and 430px widths.
- Check Firebase console logs and rules simulator if a request fails.

## 5. Publish website / Android

Build the site with `npm run build`. Deploy the `dist` folder using a hosting service compatible with your setup. Free-tier quotas and account requirements may apply. Once the web version works, it can be wrapped with Capacitor for Android, but Android SDK/build/signing setup may be needed. A PWA can be added to the home screen as a first simpler step.

## AI builder prompt

Build a production-minded, mobile-first social networking web app called FriendConnect using React, TypeScript, Tailwind CSS and Firebase Authentication + Firestore. Include signup/login/password reset, user profiles, privacy controls, one-to-one real-time chat, blocking/reporting, weekly/monthly/yearly subscription plans, manual bank/UPI QR payment submission with pending admin review, and an admin dashboard. Use secure server-verified admin custom claims and Firestore rules. Never activate a subscription from a client-side claim or screenshot. Keep prices as configurable placeholders. Include full setup, security rules, testing and deployment instructions. Do not claim features work unless implemented and tested.
