import { useEffect, useState } from "react";
import { supabase } from "./lib/supabaseClient";

const plans = [
  { id: "weekly", name: "Weekly", note: "A little spark", price: "Price set by admin" },
  { id: "monthly", name: "Monthly", note: "Most popular", price: "Price set by admin" },
  { id: "yearly", name: "Yearly", note: "The long story", price: "Price set by admin" }
];

export default function App() {
  const [session, setSession] = useState(null);
  const [mode, setMode] = useState("signup");
  const [tab, setTab] = useState("discover");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [adult, setAdult] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState("monthly");
  const [reference, setReference] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => authListener.subscription.unsubscribe();
  }, []);

  async function authSubmit(event) {
    event.preventDefault();
    setNotice("");
    if (!supabase) return setNotice("Setup needed: connect your Supabase project in .env.local first.");
    if (mode === "signup" && !adult) return setNotice("Please confirm that you are 18 or older.");
    if (password.length < 8) return setNotice("Use a password with at least 8 characters.");
    setBusy(true);
    try {
      const result = mode === "signup"
        ? await supabase.auth.signUp({ email, password, options: { data: { display_name: name.trim(), adult_confirmed: true } } })
        : await supabase.auth.signInWithPassword({ email, password });
      setNotice(result.error ? result.error.message : mode === "signup" ? "Signup submitted. Check your email if confirmation is enabled." : "Welcome back.");
    } finally { setBusy(false); }
  }

  async function submitPayment(event) {
    event.preventDefault();
    if (!supabase || !session) return setNotice("Connect Supabase and log in before submitting a payment request.");
    if (reference.trim().length < 4) return setNotice("Enter the transaction reference from your UPI app.");
    setBusy(true);
    const { error } = await supabase.from("payment_requests").insert({
      user_id: session.user.id,
      plan: selectedPlan,
      payment_reference: reference.trim(),
      amount_paise: 1,
      status: "pending"
    });
    setBusy(false);
    setNotice(error ? error.message : "Request sent for admin verification. Paid access remains inactive until verified.");
    if (!error) setReference("");
  }

  async function logout() {
    if (supabase) await supabase.auth.signOut();
    setSession(null);
    setNotice("You have logged out.");
  }

  return <div className="app-shell">
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <header className="nav">
      <a className="wordmark" href="#" onClick={e=>e.preventDefault()}><span className="logo-gem">♥</span><span>friendconnect<small>L U X E</small></span></a>
      <div className="nav-right"><span className="adult-pill"><i/> 18+ COMMUNITY</span>{session && <button className="quiet-btn" onClick={logout}>Log out ↗</button>}</div>
    </header>

    {!supabase && <div className="setup-banner"><b>Preview mode</b><span>Connect your Supabase project to enable real accounts and payments.</span></div>}

    {!session ? <main className="hero-grid">
      <section className="hero-copy">
        <div className="eyebrow"><span/> CONNECTION, WITH INTENTION</div>
        <h1>Not just a<br/><em>match.</em><br/>A feeling.</h1>
        <p className="hero-description">Meet people who feel like your kind of wonderful. Thoughtful profiles, mutual interest, and conversations that start with respect.</p>
        <div className="hero-points"><span>✦ Mutual matches only</span><span>✦ Privacy by design</span><span>✦ Adults 18+ only</span></div>
        <div className="orbital-art" aria-hidden="true"><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="orb-heart">♥</div><span className="spark s1">✦</span><span className="spark s2">✧</span><span className="spark s3">✦</span></div>
      </section>
      <section className="auth-card">
        <div className="card-topline"><span>YOUR NEXT CHAPTER</span><span>01 / 03</span></div>
        <h2>{mode === "signup" ? "Make room for magic." : "Welcome back."}</h2>
        <p className="card-subtitle">{mode === "signup" ? "Create your private corner of connection." : "Your next conversation is waiting."}</p>
        <form onSubmit={authSubmit}>
          {mode === "signup" && <label>Your display name<input value={name} onChange={e=>setName(e.target.value)} maxLength={40} required placeholder="What should we call you?"/></label>}
          <label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email" placeholder="you@example.com"/></label>
          <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required autoComplete={mode==="signup"?"new-password":"current-password"} placeholder="At least 8 characters"/></label>
          {mode === "signup" && <label className="consent"><input type="checkbox" checked={adult} onChange={e=>setAdult(e.target.checked)} required/><span>I confirm I am 18 or older and agree to respectful, consent-first interactions.</span></label>}
          <button className="gold-button" disabled={busy}>{busy ? "One moment…" : mode === "signup" ? "Create my account <" : "Log in <"}</button>
        </form>
        <button className="switch-mode" onClick={()=>{setMode(mode==="signup"?"login":"signup");setNotice("");}}>{mode==="signup"?"Already have an account? Log in":"New to FriendConnect? Create an account"}</button>
        <div className="secure-note">♢ Your personal details are yours. Always.</div>
      </section>
    </main> : <main className="member-area">
      <div className="member-heading"><div><div className="eyebrow"><span/> YOUR PRIVATE LOUNGE</div><h1>Good to see you, <em>{session.user.user_metadata?.display_name || "you"}.</em></h1><p>Let genuine connection happen at your pace.</p></div><div className="profile-monogram">{(session.user.user_metadata?.display_name || "F").slice(0,1).toUpperCase()}</div></div>
      <nav className="tabs">{["discover","profile","payments","safety"].map(t=><button key={t} onClick={()=>setTab(t)} className={tab===t?"active":""}>{t==="discover"?"♡ Discover":t==="profile"?"◉ My profile":t==="payments"?"◇ Membership":"♧ Safety"}</button>)}</nav>
      {tab==="discover" && <section className="feature-panel"><div className="feature-symbol">✧</div><div className="eyebrow">YOUR STORY STARTS HERE</div><h2>Good connections<br/><em>begin with you.</em></h2><p>Once profile creation and secure matching rules are configured, your discovery feed will live here. A match is created only when both people show interest.</p><div className="feature-tags"><span>Mutual interest</span><span>Respectful chat</span><span>Privacy first</span></div></section>}
      {tab==="profile" && <section className="content-panel"><div className="eyebrow">YOUR IDENTITY</div><h2>Your profile</h2><p className="subtle">Signed in as <b>{session.user.email}</b></p><p>Profile editing, interests, photos and private age verification are the next backend-connected features to implement.</p></section>}
      {tab==="payments" && <section className="content-panel payment-panel"><div className="eyebrow">A LITTLE MORE POSSIBILITY</div><h2>Choose your membership.</h2><p className="subtle">Pay using UPI and submit your transaction reference for manual verification.</p><div className="plan-grid">{plans.map(p=><button type="button" key={p.id} className={`plan-card ${selectedPlan===p.id?"chosen":""}`} onClick={()=>setSelectedPlan(p.id)}><span className="plan-note">{p.note}</span><b>{p.name}</b><small>{p.price}</small></button>)}</div><div className="qr-panel"><div><div className="eyebrow">SECURE UPI CHECKOUT</div><h3>Scan to pay</h3><p>Verify the recipient and exact amount inside your UPI app before paying.</p><div className="upi-name">Seernivasan Seerni (SKG)</div></div><img src="/upi-qr.png" alt="UPI QR provided by the app owner"/></div><form onSubmit={submitPayment}><label>Selected plan<input value={selectedPlan} readOnly/></label><label>Transaction reference / UTR<input value={reference} onChange={e=>setReference(e.target.value)} required minLength={4} placeholder="Enter UPI transaction reference"/></label><button className="gold-button" disabled={busy}>{busy?"Submitting…":"Send for verification <"}</button></form><p className="fine-print">Payment requests remain pending until the administrator verifies the transaction. The current sample amount is a placeholder; configure real prices and secure server-side approval before accepting users.</p></section>}
      {tab==="safety" && <section className="content-panel"><div className="eyebrow">CARE IS A FEATURE</div><h2>Your comfort matters.</h2><div className="safety-row"><span>01</span><div><b>Mutual consent</b><p>Chat should be available only after a mutual match.</p></div></div><div className="safety-row"><span>02</span><div><b>Block & report</b><p>Implement and test block/report actions before opening the app to the public.</p></div></div><div className="safety-row"><span>03</span><div><b>Keep it private</b><p>Never share your password, OTP, UPI PIN or exact home location.</p></div></div></section>}
    </main>}

    {notice && <div className="toast" role="status"><span>✦</span>{notice}<button onClick={()=>setNotice("")}>×</button></div>}
    <footer className="footer"><span>FRIENDCONNECT LUXE</span><span>Made for meaningful connections · 18+ only</span><span>CONSENT · PRIVACY · RESPECT</span></footer>
  </div>;
}