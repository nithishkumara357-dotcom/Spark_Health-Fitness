// api.js — thin fetch wrapper for the Spark Health backend, plus small
// shared helpers used by every page (auth guard, sidebar user chip).

const API_BASE = "/api";

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body.error) message = body.error;
    } catch (_) {}
    throw new Error(message);
  }
  if (res.status === 204) return null;
  return res.json();
}

const api = {
  get: (path) => apiRequest(path),
  post: (path, data) => apiRequest(path, { method: "POST", body: JSON.stringify(data) }),
  patch: (path, data) => apiRequest(path, { method: "PATCH", body: JSON.stringify(data || {}) }),
  del: (path) => apiRequest(path, { method: "DELETE" }),
};

// ---- Auth (demo-only, stored in localStorage) ----------------------------
function getCurrentUser() {
  const raw = localStorage.getItem("sparkHealthUser");
  return raw ? JSON.parse(raw) : null;
}

function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = "/index.html";
    return null;
  }
  return user;
}

function logout() {
  localStorage.removeItem("sparkHealthUser");
  window.location.href = "/index.html";
}

function initials(name) {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function paintUserChip(user) {
  const nameEl = document.getElementById("sidebarUserName");
  const emailEl = document.getElementById("sidebarUserEmail");
  const avatarEl = document.getElementById("sidebarUserAvatar");
  if (nameEl) nameEl.textContent = user.name;
  if (emailEl) emailEl.textContent = user.email;
  if (avatarEl) avatarEl.textContent = initials(user.name);
}

function formatDate(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logoutLink");
  if (logoutLink) logoutLink.addEventListener("click", (e) => { e.preventDefault(); logout(); });
});
