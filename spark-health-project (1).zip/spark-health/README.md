# Spark Health

Health & Wellness mobile-first web app — rebuilt as a runnable full-stack
project based on the Spark Health viva presentation (Dashboard, Medicine
Reminder, Doctor Appointment, Health Records, Emergency Support).

## Structure

```
spark-health/
├── backend/              Node.js + Express API
│   ├── server.js         Entry point — also serves the frontend
│   ├── db.js             Tiny JSON-file "database" helper
│   ├── data/*.json        Seed data (medicines, doctors, appointments, records, emergency, users)
│   └── routes/           One file per module (auth, dashboard, medicines, appointments, records, emergency)
├── frontend/              Vanilla HTML/CSS/JS (no build step)
│   ├── index.html         Sign-in page
│   ├── pages/              dashboard.html, medicines.html, appointments.html, records.html, emergency.html
│   ├── css/style.css      Design system (colors, type, components)
│   └── js/api.js          Fetch wrapper + auth guard shared by every page
└── README.md
```

## Running it

Requires [Node.js](https://nodejs.org) 18+.

```bash
cd backend
npm install
npm start
```

Then open **http://localhost:4000** — the Express server serves the
frontend directly, so there's nothing else to start. The API alone lives
under `http://localhost:4000/api/...`.

Demo login (pre-filled on the sign-in screen):
- Email: `aarav.verma@example.com`
- Password: `spark123`

## Data storage

Data is stored in plain JSON files under `backend/data/` — no database
server to install. Every route only calls `read()`/`write()` in `db.js`,
so swapping in a real database (Postgres, MongoDB, etc.) later means
changing that one file, not every route.

This is a demo project: passwords are stored in plain text and there's no
session/JWT layer. Add proper auth (bcrypt + sessions or JWT) before using
this with real user data.

## API reference

| Method | Route | Description |
|---|---|---|
| POST | `/api/auth/login` | `{ email, password }` → user profile |
| GET | `/api/dashboard` | Summary for the home screen |
| GET/POST | `/api/medicines` | List / add a reminder |
| PATCH | `/api/medicines/:id/taken` | Toggle taken status |
| DELETE | `/api/medicines/:id` | Remove a reminder |
| GET | `/api/appointments/doctors` | Search doctors (`?q=`, `?specialty=`) |
| GET/POST | `/api/appointments` | List / book appointments |
| DELETE | `/api/appointments/:id` | Cancel an appointment |
| GET/POST | `/api/records` | List / add a health record |
| DELETE | `/api/records/:id` | Remove a record |
| GET/POST | `/api/emergency` | List / add an emergency contact |
| DELETE | `/api/emergency/:id` | Remove a contact |

## Modules (from the presentation)

- **Dashboard** — quick access to all healthcare services
- **Medicine Reminder** — create, edit, and track medication schedules
- **Doctor Appointment** — search doctors and book consultation slots
- **Health Records** — store and access healthcare information
- **Emergency Support** — one-tap emergency contact access
