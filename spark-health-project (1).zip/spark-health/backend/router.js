// router.js
// A deliberately tiny router so the whole backend runs on Node's built-in
// `http` module with zero npm dependencies. Supports path params
// (":id") and query strings, and mimics the handful of Express-like
// conveniences the routes use (req.params, req.query, req.body, res.json).

const { URL } = require("url");

function compilePattern(pattern) {
  const paramNames = [];
  const regexStr = pattern
    .split("/")
    .map((segment) => {
      if (segment.startsWith(":")) {
        paramNames.push(segment.slice(1));
        return "([^/]+)";
      }
      return segment.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    })
    .join("/");
  return { regex: new RegExp(`^${regexStr}$`), paramNames };
}

class Router {
  constructor() {
    this.routes = []; // { method, regex, paramNames, handler }
  }

  _add(method, pattern, handler) {
    const { regex, paramNames } = compilePattern(pattern);
    this.routes.push({ method, regex, paramNames, handler });
  }

  get(pattern, handler) { this._add("GET", pattern, handler); }
  post(pattern, handler) { this._add("POST", pattern, handler); }
  patch(pattern, handler) { this._add("PATCH", pattern, handler); }
  delete(pattern, handler) { this._add("DELETE", pattern, handler); }

  match(method, pathname) {
    for (const route of this.routes) {
      if (route.method !== method) continue;
      const m = route.regex.exec(pathname);
      if (m) {
        const params = {};
        route.paramNames.forEach((name, i) => (params[name] = m[i + 1]));
        return { handler: route.handler, params };
      }
    }
    return null;
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => (raw += chunk));
    req.on("end", () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (err) {
        reject(new Error("Invalid JSON body"));
      }
    });
    req.on("error", reject);
  });
}

function sendJSON(res, status, data) {
  const body = data === null || data === undefined ? "" : JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  res.end(body);
}

module.exports = { Router, readBody, sendJSON, URL };
