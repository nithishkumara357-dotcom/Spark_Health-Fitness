// routes/medicines.js
const { read, write, nextId } = require("../db");

module.exports = function registerMedicineRoutes(router) {
  // GET /api/medicines
  router.get("/api/medicines", (req, res) => {
    res.status(200).json(read("medicines"));
  });

  // POST /api/medicines  { name, dosage, time, frequency }
  router.post("/api/medicines", (req, res, { body }) => {
    const { name, dosage, time, frequency } = body;
    if (!name || !time) {
      return res.status(400).json({ error: "name and time are required." });
    }
    const medicines = read("medicines");
    const newMed = {
      id: nextId(medicines),
      name,
      dosage: dosage || "",
      time,
      frequency: frequency || "Daily",
      taken: false,
    };
    medicines.push(newMed);
    write("medicines", medicines);
    res.status(201).json(newMed);
  });

  // PATCH /api/medicines/:id/taken — toggle taken status
  router.patch("/api/medicines/:id/taken", (req, res, { params }) => {
    const id = Number(params.id);
    const medicines = read("medicines");
    const med = medicines.find((m) => m.id === id);
    if (!med) return res.status(404).json({ error: "Medicine not found." });

    med.taken = !med.taken;
    write("medicines", medicines);
    res.status(200).json(med);
  });

  // DELETE /api/medicines/:id
  router.delete("/api/medicines/:id", (req, res, { params }) => {
    const id = Number(params.id);
    const medicines = read("medicines");
    const filtered = medicines.filter((m) => m.id !== id);
    if (filtered.length === medicines.length) {
      return res.status(404).json({ error: "Medicine not found." });
    }
    write("medicines", filtered);
    res.status(204).json(null);
  });
};
