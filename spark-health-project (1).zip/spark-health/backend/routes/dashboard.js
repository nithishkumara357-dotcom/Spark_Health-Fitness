// routes/dashboard.js
const { read } = require("../db");

module.exports = function registerDashboardRoutes(router) {
  // GET /api/dashboard — summary card for the home screen
  router.get("/api/dashboard", (req, res) => {
    const medicines = read("medicines");
    const appointments = read("appointments");
    const records = read("records");
    const emergency = read("emergency");

    const nextMedicine = medicines.find((m) => !m.taken) || null;
    const nextAppointment = appointments[0] || null;

    res.status(200).json({
      nextMedicine,
      nextAppointment,
      recordCount: records.length,
      emergencyContactCount: emergency.length,
      medicinesDueToday: medicines.filter((m) => !m.taken).length,
    });
  });
};
