// routes/appointments.js
const { read, write, nextId } = require("../db");

module.exports = function registerAppointmentRoutes(router) {
  // GET /api/appointments/doctors?specialty=&q=
  router.get("/api/appointments/doctors", (req, res, { query }) => {
    const { specialty, q } = query;
    let doctors = read("doctors");

    if (specialty) {
      doctors = doctors.filter((d) => d.specialty.toLowerCase() === specialty.toLowerCase());
    }
    if (q) {
      const term = q.toLowerCase();
      doctors = doctors.filter((d) => d.name.toLowerCase().includes(term));
    }
    res.status(200).json(doctors);
  });

  // GET /api/appointments — the user's booked appointments
  router.get("/api/appointments", (req, res) => {
    res.status(200).json(read("appointments"));
  });

  // POST /api/appointments  { doctorId, date, time }
  router.post("/api/appointments", (req, res, { body }) => {
    const { doctorId, date, time } = body;
    const doctors = read("doctors");
    const doctor = doctors.find((d) => d.id === Number(doctorId));
    if (!doctor) return res.status(404).json({ error: "Doctor not found." });
    if (!date || !time) {
      return res.status(400).json({ error: "date and time are required." });
    }

    const appointments = read("appointments");
    const newAppt = {
      id: nextId(appointments),
      doctorId: doctor.id,
      doctorName: doctor.name,
      specialty: doctor.specialty,
      date,
      time,
      status: "Confirmed",
    };
    appointments.push(newAppt);
    write("appointments", appointments);
    res.status(201).json(newAppt);
  });

  // DELETE /api/appointments/:id — cancel
  router.delete("/api/appointments/:id", (req, res, { params }) => {
    const id = Number(params.id);
    const appointments = read("appointments");
    const filtered = appointments.filter((a) => a.id !== id);
    if (filtered.length === appointments.length) {
      return res.status(404).json({ error: "Appointment not found." });
    }
    write("appointments", filtered);
    res.status(204).json(null);
  });
};
