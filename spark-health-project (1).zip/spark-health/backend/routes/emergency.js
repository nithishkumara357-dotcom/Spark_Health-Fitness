// routes/emergency.js
const { read, write, nextId } = require("../db");

module.exports = function registerEmergencyRoutes(router) {
  // GET /api/emergency
  router.get("/api/emergency", (req, res) => {
    res.status(200).json(read("emergency"));
  });

  // POST /api/emergency  { name, relation, phone }
  router.post("/api/emergency", (req, res, { body }) => {
    const { name, relation, phone } = body;
    if (!name || !phone) {
      return res.status(400).json({ error: "name and phone are required." });
    }
    const contacts = read("emergency");
    const newContact = { id: nextId(contacts), name, relation: relation || "", phone };
    contacts.push(newContact);
    write("emergency", contacts);
    res.status(201).json(newContact);
  });

  // DELETE /api/emergency/:id
  router.delete("/api/emergency/:id", (req, res, { params }) => {
    const id = Number(params.id);
    const contacts = read("emergency");
    const filtered = contacts.filter((c) => c.id !== id);
    if (filtered.length === contacts.length) {
      return res.status(404).json({ error: "Contact not found." });
    }
    write("emergency", filtered);
    res.status(204).json(null);
  });
};
