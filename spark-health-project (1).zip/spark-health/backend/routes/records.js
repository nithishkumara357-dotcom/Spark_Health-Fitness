// routes/records.js
const { read, write, nextId } = require("../db");

module.exports = function registerRecordRoutes(router) {
  // GET /api/records
  router.get("/api/records", (req, res) => {
    res.status(200).json(read("records"));
  });

  // POST /api/records  { title, type, date, provider, notes }
  router.post("/api/records", (req, res, { body }) => {
    const { title, type, date, provider, notes } = body;
    if (!title || !date) {
      return res.status(400).json({ error: "title and date are required." });
    }
    const records = read("records");
    const newRecord = {
      id: nextId(records),
      title,
      type: type || "General",
      date,
      provider: provider || "",
      notes: notes || "",
    };
    records.push(newRecord);
    write("records", records);
    res.status(201).json(newRecord);
  });

  // DELETE /api/records/:id
  router.delete("/api/records/:id", (req, res, { params }) => {
    const id = Number(params.id);
    const records = read("records");
    const filtered = records.filter((r) => r.id !== id);
    if (filtered.length === records.length) {
      return res.status(404).json({ error: "Record not found." });
    }
    write("records", filtered);
    res.status(204).json(null);
  });
};
