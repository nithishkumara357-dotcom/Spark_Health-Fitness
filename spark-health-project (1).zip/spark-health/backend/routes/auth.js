// routes/auth.js
const { read } = require("../db");

module.exports = function registerAuthRoutes(router) {
  // POST /api/auth/login  { email, password } -> user profile
  // Demo-only auth: matches the seeded user file, no sessions/JWT.
  router.post("/api/auth/login", (req, res, { body }) => {
    const { email, password } = body;
    const users = read("users");
    const user = users.find((u) => u.email === email && u.password === password);

    if (!user) {
      return res.status(401).json({ error: "Invalid email or password." });
    }
    const { password: _pw, ...safeUser } = user;
    res.status(200).json({ user: safeUser });
  });
};
