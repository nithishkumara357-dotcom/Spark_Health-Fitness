// server.js
// Spark Health backend — pure Node.js `http` server (no Express, no npm
// install required). Serves the JSON API under /api/* and the static
// frontend for everything else, so `node server.js` is the only command
// needed to run the whole app.

const http = require("http");
const fs = require("fs");
const path = require("path");
const { Router, readBody, sendJSON, URL } = require("./router");

const PORT = process.env.PORT || 4000;
const FRONTEND_DIR = path.join(__dirname, "..", "frontend");

const router = new Router();
require("./routes/auth")(router);
require("./routes/dashboard")(router);
require("./routes/medicines")(router);
require("./routes/appointments")(router);
require("./routes/records")(router);
require("./routes/emergency")(router);

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

function serveStatic(req, res, pathname) {
  let filePath = path.join(FRONTEND_DIR, pathname === "/" ? "index.html" : pathname);

  // Guard against escaping the frontend directory.
  if (!filePath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      // SPA-ish fallback: unknown paths without a file extension get index.html.
      if (!path.extname(pathname)) {
        return fs.readFile(path.join(FRONTEND_DIR, "index.html"), (err2, indexData) => {
          if (err2) {
            res.writeHead(404);
            return res.end("Not found");
          }
          res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
          res.end(indexData);
        });
      }
      res.writeHead(404);
      return res.end("Not found");
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME_TYPES[ext] || "application/octet-stream" });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = decodeURIComponent(url.pathname);

  // Adds res.status(code) / res.json(data) sugar used by every route.
  res.status = function (code) {
    this._statusCode = code;
    return this;
  };
  res.json = function (data) {
    sendJSON(this, this._statusCode || 200, data);
  };

  if (req.method === "OPTIONS") {
    return sendJSON(res, 204, null);
  }

  if (pathname.startsWith("/api/")) {
    const match = router.match(req.method, pathname);
    if (!match) {
      return sendJSON(res, 404, { error: "Not found" });
    }
    try {
      const body = req.method === "POST" || req.method === "PATCH" ? await readBody(req) : {};
      const query = Object.fromEntries(url.searchParams.entries());
      match.handler(req, res, { params: match.params, query, body });
    } catch (err) {
      sendJSON(res, 400, { error: err.message || "Bad request" });
    }
    return;
  }

  serveStatic(req, res, pathname);
});

server.listen(PORT, () => {
  console.log(`Spark Health API + frontend running at http://localhost:${PORT}`);
});
